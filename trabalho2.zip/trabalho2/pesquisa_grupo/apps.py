from django.apps import AppConfig

class PesquisaGrupoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pesquisa_grupo'
